@echo off
start https://youtu.be/xMHJGd3wwZk?si=Go-uEBtmrWm--aqv